package com.javarush.task.task03.task0317;

/* 
Путь самурая
*/

public class Solution {
    public static void main(String[] args) {
        System.out.println("日本語");

    }
}
