package com.javarush.task.task03.task0313;

/* 
Мама мыла раму
*/

public class Solution {
    public static void main(String[] args) {
        String a = "Мама";
        String b = "Мыла";
        String c = "Раму";
        System.out.println(a+b+c +"\n"
                +a+c+b +"\n"
                +b+a+c +"\n"
                +b+c+a +"\n"
                +c+a+b +"\n"
                +c+b+a);
    }
}
