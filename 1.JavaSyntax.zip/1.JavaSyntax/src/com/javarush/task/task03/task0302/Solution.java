package com.javarush.task.task03.task0302;

/* 
Немедленно в печать
*/

import java.sql.SQLOutput;

public class Solution {
    public static void printString(String s){
        System.out.println(s);
    }

    public static void main(String[] args) {
        printString("Hello, Amigo!");
    }
}
