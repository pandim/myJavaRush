package com.javarush.task.task03.task0306;

/* 
Головоломка со скобками
*/

public class Solution {
    public static void main(String[] args) {
        System.out.println(2 * (3 + 4 * (5 + 6 * 7)));
    }
}
