package com.javarush.task.task06.task0618;

/* 
KissMyShinyMetalAss
*/

public class Solution {
    public static class KissMyShinyMetalAss

    {

    }

    public static void main(String[] args) {
        KissMyShinyMetalAss Ass = new KissMyShinyMetalAss();
        System.out.println(Ass);
    }
}
