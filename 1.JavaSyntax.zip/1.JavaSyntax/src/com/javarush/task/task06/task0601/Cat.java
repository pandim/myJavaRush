package com.javarush.task.task06.task0601;

/* 
Метод finalize класса Cat
*/

public abstract class Cat {
    protected void finalize() throws Throwable {

    }

    public static void main(String[] args) {

    }
}
