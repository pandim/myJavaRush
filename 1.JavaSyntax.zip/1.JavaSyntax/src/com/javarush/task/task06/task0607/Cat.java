package com.javarush.task.task06.task0607;

/* 
Классовый счетчик
*/

public class Cat {
    static int catCount = 0;

    public Cat() {
        Cat.catCount++;
    }

    public static void main(String[] args) {

    }
}
