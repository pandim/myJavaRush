package com.javarush.task.task05.task0524;

/* 
Основа колеса
*/

public class Circle {
    public double x;
    public double y;
    public double r;

    public Circle(double x, double y, double r) {
        this.x = x;
        this.y = y;
        this.r = r;
    }

    public static void main(String[] args) {

    }
}
