package com.javarush.task.task05.task0506;

/* 
Человечки
*/

public class Person {
    //имя String name, возраст int age, адрес String address, пол char sex.
    protected String name;
    protected  int age;
    protected String address;
    protected char sex;



    public static void main(String[] args) {

    }
}
