package com.javarush.task.task08.task0807;

/* 
LinkedList и ArrayList
*/

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class Solution {
    public static Object createArrayList() {
        List arrayList = new ArrayList();
        return arrayList;
    }

    public static Object createLinkedList() {
        List linkedList = new LinkedList<>();
return linkedList;
    }

    public static void main(String[] args) {

    }
}
