package com.javarush.task.task08.task0813;

import java.util.HashSet;
import java.util.Set;

/* 
20 слов на букву «Л»
*/

public class Solution {
    public static Set<String> createSet() {
        Set<String> set = new HashSet<>();
        for (int i = 0; i < 20; i++) { set.add("Лум" + (char)(70+i));}
        return set;
    }

    public static void main(String[] args) {
        Set<String> set = createSet();
//        for (String s: set) {
//                    System.out.println(s);
//
//        }
    }
}
