package com.javarush.task.task04.task0435;

/* 
Четные числа
*/

public class Solution {
    public static void main(String[] args) {
        for (int i = 2; i <= 100 ; i = i + 2) {
            System.out.println(i);
        }
    }
}
