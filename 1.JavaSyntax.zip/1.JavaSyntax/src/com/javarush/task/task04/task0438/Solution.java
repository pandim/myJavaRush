package com.javarush.task.task04.task0438;

/* 
Рисуем линии
*/

public class Solution {
    public static void main(String[] args) {
        for (int i = 1; i <= 10 ; i++) System.out.print("8");
        System.out.println("");
        for (int i = 1; i <= 10 ; i++) System.out.println("8");
    }
}
