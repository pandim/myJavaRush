package com.javarush.task.task04.task0416;

/* 
Переходим дорогу вслепую
*/

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Solution {
    public static void main(String[] args) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        double n = Double.parseDouble(reader.readLine());
        int k = (int) n % 5;
        switch (k){
            case 0:
            case 1:
            case 2:
                System.out.println("зеленый"); break;
            case 3:
                System.out.println("желтый"); break;
            case 4:
                System.out.println("красный");

        }


    }
}