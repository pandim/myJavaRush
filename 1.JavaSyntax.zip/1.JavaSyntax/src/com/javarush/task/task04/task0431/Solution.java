package com.javarush.task.task04.task0431;

/* 
От 10 до 1
*/

public class Solution {
    public static void main(String[] args) {
        int i = 10;
        while (i > 0) System.out.println(i--);
    }
}
