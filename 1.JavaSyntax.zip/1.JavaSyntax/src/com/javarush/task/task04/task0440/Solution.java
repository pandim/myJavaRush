package com.javarush.task.task04.task0440;

/* 
Достойная оплата труда
*/

public class Solution {
    public static void main(String[] args) {
        for (int i = 0; i < 100; i++) {
            System.out.println("Я никогда не буду работать за копейки. Амиго");
        }

    }
}
