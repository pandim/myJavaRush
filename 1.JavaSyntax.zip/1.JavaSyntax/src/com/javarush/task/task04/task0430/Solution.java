package com.javarush.task.task04.task0430;

/* 
От 1 до 10
*/

public class Solution {
    public static void main(String[] args) {
int i = 0;
        while (i < 10) System.out.println(++i);
    }
}